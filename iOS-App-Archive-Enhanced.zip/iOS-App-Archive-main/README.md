<img align="left" width="90" height="100" src="cdn/icon/white-logo.png">

# iOS App Archive
---
- Website link: https://theoriginalhotshot.github.io/iOS-App-Archive/
- Archive link: https://archive.org/details/@legacyios_archive

> None of the apps are hosted on the site, only the app icons are.
